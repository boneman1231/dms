package test;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import test.entity.GetDataRequest;
import test.entity.GetDataResponse;

@Endpoint
public class SoapWS {

	@PayloadRoot(namespace = "http://www.test.com/", localPart = "getDataRequest")
	@ResponsePayload
	public GetDataResponse getData(@RequestPayload GetDataRequest request) {				
		GetDataResponse response = new GetDataResponse();
		response.setValue("OK");
		return response;
	}

}
